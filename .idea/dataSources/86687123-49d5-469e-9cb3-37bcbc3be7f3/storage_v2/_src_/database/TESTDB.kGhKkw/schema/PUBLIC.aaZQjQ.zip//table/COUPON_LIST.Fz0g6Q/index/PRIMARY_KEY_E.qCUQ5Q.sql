create unique index PRIMARY_KEY_E
    on COUPON_LIST (COUPON_LIST_ID);

