create unique index PRIMARY_KEY_8B
    on ORDERS (ORDERS_ID);

