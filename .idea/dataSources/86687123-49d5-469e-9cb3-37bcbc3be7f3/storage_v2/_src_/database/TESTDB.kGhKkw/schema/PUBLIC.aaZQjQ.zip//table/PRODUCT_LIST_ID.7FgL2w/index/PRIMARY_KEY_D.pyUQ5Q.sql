create unique index PRIMARY_KEY_D
    on PRODUCT_LIST_ID (PRODUCT_LIST_ID);

