create unique index PRIMARY_KEY_A
    on FREQ_QUESTION (FREQ_QUESTION_ID);

