create unique index PRIMARY_KEY_3
    on EVENT (EVENT_ID);

