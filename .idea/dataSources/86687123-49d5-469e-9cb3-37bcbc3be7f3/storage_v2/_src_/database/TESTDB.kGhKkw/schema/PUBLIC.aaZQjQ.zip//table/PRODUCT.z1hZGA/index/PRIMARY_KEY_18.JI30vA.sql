create unique index PRIMARY_KEY_18
    on PRODUCT (PRODUCT_ID);

